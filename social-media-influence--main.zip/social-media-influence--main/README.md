# social-media-influence-
Social media platforms like Instagram, Facebook, Twitter, and YouTube have become powerful marketing tools. This project analyzes how their use affects consumer buying decisions using a Kaggle dataset and machine learning to predict purchase intent based on behavior and demographics.
